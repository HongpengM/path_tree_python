~/opt/anaconda3/bin/python -m unittest tests/*.py
