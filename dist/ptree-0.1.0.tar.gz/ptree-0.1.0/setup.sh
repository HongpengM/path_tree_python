py setup.py sdist
pi install ./dist/*.tar.gz